const display = document.getElementById("display");
const buttons = Array.from(document.getElementsByTagName("button"));
let currentNumber = "";
let previousNumber = "";
let operation = null;
let inputHistory = "";

buttons.map(button => {
  button.addEventListener("click", () => {
    const buttonText = button.innerText;

    if (buttonText === "C") {
      currentNumber = "";
      previousNumber = "";
      operation = null;
      display.value = "";
    } else if (buttonText === "+" || buttonText === "-" || buttonText === "*" || buttonText === "/" || buttonText === "%") {
      operation = buttonText;
      previousNumber = currentNumber;
      currentNumber = "";
    } else if (buttonText === "=") {
      let result;
      const prevNum = parseFloat(previousNumber);
      const currNum = parseFloat(currentNumber);

      switch (operation) {
        case "+":
          result = prevNum + currNum;
          break;
        case "-":
          result = prevNum - currNum;
          break;
        case "*":
          result = prevNum * currNum;
          break;
        case "/":
          if (currNum === 0) {
            alert("Cannot divide by zero");
            return;
          }
          result = prevNum / currNum;
          break;
        case "%":
          result = prevNum % currNum;
          break;

        default:
          return;
      }

      currentNumber = result.toString();
      inputHistory += currentNumber;
      operation = null;
      previousNumber = "";
    } else {
      currentNumber += buttonText;
      inputHistory += buttonText;
    }

    display.value = currentNumber;
  });
});




