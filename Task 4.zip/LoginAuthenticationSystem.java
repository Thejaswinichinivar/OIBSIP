import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class LoginAuthenticationSystem {
    private static Map<String, String> users = new HashMap<>();

    public static void main(String[] args) {
        registerUser("admin", "password123"); 
        loginUser();
    }

    private static void registerUser(String username, String password) {
        String hashedPassword = hashPassword(password);
        users.put(username, hashedPassword);
        System.out.println("User registered successfully!");
    }

    private static void loginUser() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter username:");
        String username = scanner.nextLine();
        System.out.println("Enter password:");
        String password = scanner.nextLine();
        if (authenticateUser(username, password)) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Invalid username or password. Please try again.");
        }
    }

    private static boolean authenticateUser(String username, String password) {
        String storedPassword = users.get(username);
        if (storedPassword != null) {
            String hashedPassword = hashPassword(password);
            return hashedPassword.equals(storedPassword);
        }
        return false;
    }

    private static String hashPassword(String password) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            String salt = "random_salt";
            String saltedPassword = password + salt;
            byte[] hashedBytes = messageDigest.digest(saltedPassword.getBytes());
            StringBuilder stringBuilder = new StringBuilder();
            for (byte hashedByte : hashedBytes) {
                stringBuilder.append(Integer.toString((hashedByte & 0xff) + 0x100, 16).substring(1));
            }
            return stringBuilder.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}