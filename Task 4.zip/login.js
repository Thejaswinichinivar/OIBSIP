document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
  
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
  
    if (username && password) {
      alert('Login successful!');
      window.location.href = 'secured.html'; 
    } else {
      alert('Invalid username or password. Please try again.');
    }
  });