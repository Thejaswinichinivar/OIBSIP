document.addEventListener("DOMContentLoaded", function() {
    const newTaskTitleInput = document.getElementById("new-task-title-input");
    const newTaskDescriptionInput = document.getElementById("new-task-description-input");
    const addTaskButton = document.getElementById("add-task-button");
    const pendingTasksList = document.getElementById("pending-tasks");
    const completedTasksList = document.getElementById("completed-tasks");
    const taskForm = document.getElementById("task-form");
  
    if (!newTaskTitleInput || !newTaskDescriptionInput || !addTaskButton || !pendingTasksList || !completedTasksList || !taskForm) {
      console.error("One or more required elements not found.");
      return;
    }
  
    const titleErrorMessage = document.getElementById("title-error-message");
    const descriptionErrorMessage = document.getElementById("description-error-message");
  
    if (!titleErrorMessage || !descriptionErrorMessage) {
      console.error("One or more error message elements not found.");
      return;
    }
  
    const addedTasks = [];
  
    taskForm.addEventListener("submit", function(event) {
      event.preventDefault(); 
  
      const newTaskTitle = newTaskTitleInput.value.trim();
      const newTaskDescription = newTaskDescriptionInput.value.trim();
  
      if (newTaskTitle === "") {
        titleErrorMessage.style.display = "block";
        return;
      } else {
        titleErrorMessage.style.display = "none";
      }
  
      if (newTaskDescription === "") {
        descriptionErrorMessage.style.display = "block";
        return;
      } else {
        descriptionErrorMessage.style.display = "none";
      }
  
      
      const existingTask = addedTasks.find(task => task.title === newTaskTitle && task.description === newTaskDescription);
      if (existingTask) {
        alert("Task with the same title and description already exists.");
        return;
      }
  
     
      const newTaskLi = createTaskListItem(newTaskTitle, newTaskDescription, false);
      pendingTasksList.appendChild(newTaskLi);
  
      
      addedTasks.push({ title: newTaskTitle, description: newTaskDescription });
  
      
      newTaskTitleInput.value = "";
      newTaskDescriptionInput.value = "";
    });
  
    function createTaskListItem(title, description, isCompleted) {
      const newTaskLi = document.createElement("li");
      newTaskLi.innerHTML = `
        <div class="task-container">
          <strong class="task-title">${title}</strong>
          <span class="task-description">${description}</span>
        </div>
        <span class="date">${new Date().toLocaleDateString()}</span>
        <div class="task-actions">
          <button class="complete-button">${isCompleted ? 'Mark as Incomplete' : 'Mark as Complete'}</button>
          ${!isCompleted ? '<button class="edit-button">Edit</button>' : ''}
        </div>
      `;
      newTaskLi.dataset.date = new Date().toISOString();
      newTaskLi.classList.add(isCompleted ? "completed" : "pending");
  
      const completeButton = newTaskLi.querySelector(".complete-button");
      completeButton.addEventListener("click", toggleTaskCompletion);
  
      if (!isCompleted) {
        const editButton = newTaskLi.querySelector(".edit-button");
        editButton.addEventListener("click", editTask);
      }
  
      return newTaskLi;
    }
  
    function toggleTaskCompletion() {
      const taskLi = this.closest("li");
      if (taskLi.classList.contains("pending")) {
        taskLi.classList.remove("pending");
        taskLi.classList.add("completed");
        this.textContent = "Mark as Incomplete";
        completedTasksList.appendChild(taskLi);
      } else if (taskLi.classList.contains("completed")) {
        taskLi.classList.remove("completed");
        taskLi.classList.add("pending");
        this.textContent = "Mark as Complete";
        pendingTasksList.appendChild(taskLi);
      }
    }
  
    function editTask() {
      const taskLi = this.closest("li");
      const taskContainer = taskLi.querySelector(".task-container");
      const taskTitle = taskContainer.querySelector(".task-title");
      const taskDescription = taskContainer.querySelector(".task-description");
  
      const newTaskTitle = prompt("Enter new task title", taskTitle.textContent);
      const newTaskDescription = prompt("Enter new task description", taskDescription.textContent);
  
      if (newTaskTitle !== null && newTaskDescription !== null) {
        taskTitle.textContent = newTaskTitle;
        taskDescription.textContent = newTaskDescription;
        showEditConfirmation(taskContainer);
      }
    }
  
    function showEditConfirmation(container) {
      const message = document.createElement("p");
      message.textContent = "Task edited successfully.";
      message.style.color = "purple";
      message.style.marginTop = "5px";
      container.appendChild(message);
  
      setTimeout(() => {
        message.remove();
      }, 2000);
    }
  });
  